package com.example.getblood.notification;

public class Response {
    private String success;

}
