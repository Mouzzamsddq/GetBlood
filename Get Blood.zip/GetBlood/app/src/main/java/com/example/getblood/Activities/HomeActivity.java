package com.example.getblood.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.core.view.MenuItemCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.getblood.Fragment.Chat_list_fragment;
import com.example.getblood.Fragment.HomeFragment;
import com.example.getblood.Fragment.profileFragment;
import com.example.getblood.R;
import com.example.getblood.notification.Token;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.squareup.picasso.Picasso;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class HomeActivity extends AppCompatActivity implements  NavigationView.OnNavigationItemSelectedListener{
    private static final String TAG = "CHECK" ;
    private DrawerLayout mDrawerLayout;
    private TextView usernameTextView;
    private TextView emailTextView;
    FirebaseAuth mAuth;
    Boolean check = false;
    FirebaseUser user;
    String mUid;
    ActionBar actionBar;
    FirebaseDatabase mDatabase;
    DatabaseReference mRef;
    View hView;
    private ImageView headerImageView;
    private ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_drawer_layout);
        pd=new ProgressDialog(getApplicationContext());
        pd.setMessage("Loading....");
        pd.setCancelable(false);
        pd.setCanceledOnTouchOutside(false);
        mDatabase=FirebaseDatabase.getInstance();
        mAuth=FirebaseAuth.getInstance();
        user=mAuth.getCurrentUser();
        mRef=mDatabase.getReference().child("users");
        mDrawerLayout=findViewById(R.id.drawerLayout);
        NavigationView navigationView = findViewById(R.id.navigation_view);
        hView=navigationView.getHeaderView(0);
        headerImageView=hView.findViewById(R.id.headerImageView);
        usernameTextView=(TextView)hView.findViewById(R.id.headerUsernameTextView);
        emailTextView=(TextView)hView.findViewById(R.id.headerEmailTextView);
        Toolbar toolbar=findViewById(R.id.toolbar_tb);
        setSupportActionBar(toolbar);
         actionBar=getSupportActionBar();
        new updateHeaderTask().execute();


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this,mDrawerLayout,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close
        );
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        if(savedInstanceState==null)
        {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container,new HomeFragment())
                    .commit();
            navigationView.setCheckedItem(R.id.nav_users);
        }
        checkUserStatus();

        //update Token
        updateToken(FirebaseInstanceId.getInstance().getToken());
    }

    @Override
    protected void onResume() {
        checkUserStatus();
        super.onResume();
    }

    private void updateHeader()  {
        mRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot donorRecipientSnapshot : dataSnapshot.getChildren()) {
                    for (DataSnapshot donorsSnapshot : donorRecipientSnapshot.getChildren()) {
                        if (user.getUid().equals(donorsSnapshot.getKey())) {
                            Map<String, Object> data = (HashMap<String, Object>) donorsSnapshot.getValue();
                            String name = (String) data.get("FullName");
                            String email = (String) data.get("emailId");
                            usernameTextView.setText(name);
                            emailTextView.setText(email);
                            usernameTextView.setVisibility(View.VISIBLE);
                            emailTextView.setVisibility(View.VISIBLE);
                            String profileUrl = (String) data.get("profileImage");
                            if (!profileUrl.isEmpty()) {
                                Picasso.get().load(profileUrl).placeholder(R.drawable.baseline_account_circle_black_48).into(headerImageView);
                            }
                        }

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        pd.dismiss();
        }



    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)){
            mDrawerLayout.closeDrawer(GravityCompat.START);
        }
        else

        {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_logout:
                mAuth.signOut();
                checkUserStatus();
                break;
            case R.id.nav_users:
                //add the home fragment'
                actionBar.setTitle("Users");
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container,new HomeFragment())
                        .commit();
                break;

            case R.id.nav_profile:
                actionBar.setTitle("Profile");
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container,new profileFragment())
                        .commit();
                break;
            case R.id.nav_home:
//                Toast.makeText(this, "This is share item", Toast.LENGTH_SHORT).show();
                actionBar.setTitle("Chats");
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container,new Chat_list_fragment())
                        .commit();
                break;
//            case R.id.nav_help:
//                Toast.makeText(this, "This is help item", Toast.LENGTH_SHORT).show();
//                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    public class updateHeaderTask extends AsyncTask<Void,Void,Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            updateHeader();
            return null;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.chat_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();


        switch(id)
        {

            case R.id.actionChats:
                 actionBar.setTitle("Chats");
//                Toast.makeText(getApplicationContext(), "New Item Second", Toast.LENGTH_SHORT).show();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container,new Chat_list_fragment())
                        .commit();
                break;


        }
        return super.onOptionsItemSelected(item);
    }
    private void checkUserStatus()
    {
        FirebaseUser user=mAuth.getCurrentUser();
        if(user!=null)
        {
          mUid = user.getUid();

            SharedPreferences sp = getSharedPreferences("SP_USER",MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("Current_USERID",mUid);
            editor.apply();
        }
        else
        {
            startActivity(new Intent(getApplicationContext(),Donor.class));
            finish();

        }
    }
    public void updateToken(String token)
    {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Tokens");
        Token mToken = new Token(token);
        ref.child(mUid).setValue(mToken);
    }

}

