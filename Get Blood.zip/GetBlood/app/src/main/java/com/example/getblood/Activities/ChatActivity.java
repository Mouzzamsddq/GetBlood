package com.example.getblood.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.getblood.Adapter.AdapterChat;
import com.example.getblood.DataModel.ModelChat;
import com.example.getblood.DataModel.ModelUser;
import com.example.getblood.R;
import com.example.getblood.notification.APIService;
import com.example.getblood.notification.Client;
import com.example.getblood.notification.Data;
import com.example.getblood.notification.Response;
import com.example.getblood.notification.Sender;
import com.example.getblood.notification.Token;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;

public class ChatActivity extends AppCompatActivity {


    private static final String TAG = "TAG";
    public static final int REQUEST_IMAGE = 100;
    Uri pickedImgUri;
    //Initialize views
    FirebaseAuth mAuth;
    boolean notify =false;
    Toolbar toolbar;
    RecyclerView  recyclerView;
    ImageView profileImageView;
    TextView nameTextView,userStatusTextView;
    EditText messageEditText;
    ImageButton sendButton,attatchButton;

    String hisUID;
    String myUID;

    FirebaseDatabase mDatabase;
    DatabaseReference mRef;

    String hisImage;

    // for checking user have seen message or not
    ValueEventListener seenListener;
    DatabaseReference userRefForSeen;

    List<ModelChat> chatList;
    AdapterChat adapterChat;

    APIService apiService;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        mAuth = FirebaseAuth.getInstance();
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("");
        recyclerView = findViewById(R.id.chatRecyclerView);
        profileImageView = findViewById(R.id.chatProfileImageView);
        nameTextView = findViewById(R.id.chatNameTextView);
        userStatusTextView = findViewById(R.id.userStatusTextView);
        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);
        mDatabase = FirebaseDatabase.getInstance();
        attatchButton = findViewById(R.id.attatchButton);
        mRef = mDatabase.getReference().child("users");
        myUID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        //layout(Linear layout for recycler view

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setStackFromEnd(true);
        //recycler view properties
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);

         //create api service
        apiService = Client.getRetrofit("https://fcm.googleapis.com/").create(APIService.class);


        //intent to pass the uid so we get the recxiever profile and name
        Intent intent = getIntent();
        hisUID = intent.getStringExtra("hisUID");

        //search user to get the user info
        mRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    for (DataSnapshot donorSnapshot : userSnapshot.getChildren()) {
                        if (hisUID.equals(donorSnapshot.getKey())) {
                            //get Data
                            Map<String, Object> data = (HashMap<String, Object>) donorSnapshot.getValue();
                            String name = (String) data.get("FullName");
                            hisImage = (String) data.get("profileImage");
                            String typingStatus = (String) data.get("typingTo");
                            //check typing status
                            if (typingStatus.equals(myUID)) {
                                userStatusTextView.setText("typing...");
                            } else {
                                //get value of online status
                                String onlineStatus = (String) data.get("onlineStatus");
                                if (onlineStatus.equals("online")) {
                                    userStatusTextView.setText(onlineStatus);
                                } else {
                                    // convert timestamp to proper time and date
                                    //convert time stamp to dd/mm/yyyy hh:mm am/pm
                                    Calendar cal = Calendar.getInstance(Locale.ENGLISH);
                                    cal.setTimeInMillis(Long.parseLong(onlineStatus));
                                    String dateTime = DateFormat.format("dd/MM/yyyy hh:mm aa", cal).toString();
                                    userStatusTextView.setText("Last seen at: " + dateTime);


                                }
                            }


                            //set data
                            nameTextView.setText(name);
                            try {
                                if (!hisImage.isEmpty()) {
                                    Picasso.get().load(hisImage).placeholder(R.drawable.baseline_account_circle_black_48)
                                            .into(profileImageView);
                                }
                            } catch (Exception e) {
                                Picasso.get().load(R.drawable.baseline_account_circle_black_48).into(profileImageView);
                            }


                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        //click button to send message
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                notify = true;
                //get Text from edit Text
                String message = messageEditText.getText().toString().trim();
                //check text is empty or not
                if (TextUtils.isEmpty(message)) {
                    //text Empty
                    Toast.makeText(ChatActivity.this, "Cann't send the empty message...", Toast.LENGTH_SHORT).show();
                } else {
                    //text not empty
                    sendMessage(message);
                }
                //reset edit Text after sending message
                messageEditText.setText("");
            }
        });

        //check editText change Listener
        messageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence.toString().trim().length()==0)
                {
                    checkTypingStatus("noOne");
                }
                else
                {
                    checkTypingStatus(hisUID);// uid of receiver
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        readMessage();

        seenMessage();

        //click button to import image
        attatchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dexter.withActivity(ChatActivity.this)
                        .withPermissions(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        .withListener(new MultiplePermissionsListener() {
                            @Override
                            public void onPermissionsChecked(MultiplePermissionsReport report) {
                                if (report.areAllPermissionsGranted()) {
                                    showImagePickerOptions();
                                }

                                if (report.isAnyPermissionPermanentlyDenied()) {
                                    showSettingsDialog();
                                }
                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                                token.continuePermissionRequest();
                            }
                        }).check();
            }
        });
    }
        private void showImagePickerOptions() {
            ImagePickerActivity.showImagePickerOptions(this, new ImagePickerActivity.PickerOptionListener() {
                @Override
                public void onTakeCameraSelected() {
                    launchCameraIntent();
                }

                @Override
                public void onChooseGallerySelected() {
                    launchGalleryIntent();
                }
            });
        }

        private void launchCameraIntent() {
            Intent intent = new Intent(ChatActivity.this, ImagePickerActivity.class);
            intent.putExtra(ImagePickerActivity.INTENT_IMAGE_PICKER_OPTION, ImagePickerActivity.REQUEST_IMAGE_CAPTURE);

            // setting aspect ratio
            intent.putExtra(ImagePickerActivity.INTENT_LOCK_ASPECT_RATIO, true);
            intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_X, 1); // 16x9, 1x1, 3:4, 3:2
            intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_Y, 1);

            // setting maximum bitmap width and height
            intent.putExtra(ImagePickerActivity.INTENT_SET_BITMAP_MAX_WIDTH_HEIGHT, true);
            intent.putExtra(ImagePickerActivity.INTENT_BITMAP_MAX_WIDTH, 1000);
            intent.putExtra(ImagePickerActivity.INTENT_BITMAP_MAX_HEIGHT, 1000);

            startActivityForResult(intent, REQUEST_IMAGE);
        }

        private void launchGalleryIntent() {
            Intent intent = new Intent(ChatActivity.this, ImagePickerActivity.class);
            intent.putExtra(ImagePickerActivity.INTENT_IMAGE_PICKER_OPTION, ImagePickerActivity.REQUEST_GALLERY_IMAGE);

            // setting aspect ratio
            intent.putExtra(ImagePickerActivity.INTENT_LOCK_ASPECT_RATIO, true);
            intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_X, 1); // 16x9, 1x1, 3:4, 3:2
            intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_Y, 1);
            startActivityForResult(intent, REQUEST_IMAGE);
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
            super.onActivityResult(requestCode,resultCode,data);
            if (requestCode == REQUEST_IMAGE) {
                if (resultCode == Activity.RESULT_OK) {
                    Uri uri = data.getParcelableExtra("path");
                    pickedImgUri=uri;
                    try {
//                        // You can update this bitmap to your server
//                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
//
//                        // loading profile image from local cache
                        sendImageMessage(pickedImgUri);
//                        loadProfile(uri.toString());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }

    private void sendImageMessage(Uri pickedImgUri) throws IOException {
        //progressDialog
        ProgressDialog progressDialog = new ProgressDialog(getApplicationContext());
        progressDialog.setMessage("Sending image...");
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        String timeStamp = ""+System.currentTimeMillis();
        String fileNameAndPath = "ChatImages/"+"post_"+timeStamp;

        /* chats node will be created that will contain all images sent via chat*/

        //get Bitmap from image uri
        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), pickedImgUri);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100,baos);
        byte[] data = baos.toByteArray();  // convert images to byte
        StorageReference ref= FirebaseStorage.getInstance().getReference().child(fileNameAndPath);
        ref.putBytes(data)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                          //image uploaded
                        progressDialog.dismiss();
                        //get uri of uploaded image
                        Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                        while(!uriTask.isSuccessful());
                        String downloadUri = uriTask.getResult().toString();

                        if(uriTask.isSuccessful())
                        {
                            //add image uri and other info to database
                            DatabaseReference databaseReference =FirebaseDatabase.getInstance().getReference();


                            //setup required data
                            HashMap<String,Object> hashMap= new HashMap<>();
                            hashMap.put("sender",myUID);
                            hashMap.put("receiver",hisUID);
                            hashMap.put("message",downloadUri);
                            hashMap.put("timestamp",timeStamp);
                            hashMap.put("type","image");
                            hashMap.put("isSeen","false");

                            //put the data into firebase
                            databaseReference.child("chats").push().setValue(hashMap);

                            //send notification
                            DatabaseReference ds = FirebaseDatabase.getInstance().getReference().child("users");
                            ds.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    for (DataSnapshot d1 : dataSnapshot.getChildren())
                                    {
                                        for(DataSnapshot d2 : d1.getChildren())
                                        {
                                            if(myUID.equals(d2.getKey()))
                                            {
                                                ModelUser user = d2.getValue(ModelUser.class);

                                                if(notify)
                                                {
                                                    sendNotification(hisUID,user.getFullName(),"Sent you a photo ...");
                                                }
                                                notify = false;
                                            }
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        //failed
                        progressDialog.dismiss();
                    }
                });

    }


    private void seenMessage() {
        userRefForSeen = FirebaseDatabase.getInstance().getReference("chats");
        seenListener = userRefForSeen.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    ModelChat chat = ds.getValue(ModelChat.class);
                    if (chat.getReceiver().equals(myUID) && chat.getSender().equals(hisUID))
                    {
                        HashMap<String,Object> hasSeenHashMap = new HashMap<>();
                        hasSeenHashMap.put("isSeen",true);
                        ds.getRef().updateChildren(hasSeenHashMap);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void readMessage() {
        chatList = new ArrayList<>();
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("chats");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                chatList.clear();
                for(DataSnapshot ds : dataSnapshot.getChildren())
                {
                    ModelChat chat = ds.getValue(ModelChat.class);
                    if(chat.getReceiver().equals(myUID)  && chat.getSender().equals(hisUID) ||
                        chat.getReceiver().equals(hisUID) && chat.getSender().equals(myUID))
                    {
                        chatList.add(chat);
                    }

                    //adapter

                    adapterChat = new AdapterChat(ChatActivity.this,chatList,hisImage);
                    adapterChat.notifyDataSetChanged();
                    //set adapter to recycler View

                    recyclerView.setAdapter(adapterChat);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    private void sendMessage(String message) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
        String timeStamp = String.valueOf(System.currentTimeMillis());
        HashMap<String,Object> hashMap = new HashMap<>();
        hashMap.put("sender",myUID);
        hashMap.put("receiver",hisUID);
        hashMap.put("message",message);
        hashMap.put("timestamp",timeStamp);
        hashMap.put("isSeen",false);
        hashMap.put("type","text");
        databaseReference.child("chats").push().setValue(hashMap);



        String msg = message;
        DatabaseReference database1= FirebaseDatabase.getInstance().getReference().child("users");
        database1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds1 : dataSnapshot.getChildren())
                {
                    for(DataSnapshot ds2 : ds1.getChildren())
                    {
                        if(myUID.equals(ds2.getKey()))
                        {
                            ModelUser user = ds2.getValue(ModelUser.class);
                            if(notify)
                            {
                                sendNotification(hisUID,user.getFullName(),message);
                            }
                            notify = false;
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        //create chatlist node/child in Firebase Database
        DatabaseReference chatRef1 = FirebaseDatabase.getInstance().getReference("ChatList")
                .child(myUID)
                .child(hisUID);
        chatRef1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists())
                {
                    chatRef1.child("id").setValue(hisUID);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        //create chatlist node/child in Firebase Database
        DatabaseReference chatRef2 = FirebaseDatabase.getInstance().getReference("ChatList")
                .child(hisUID)
                .child(myUID);
        chatRef2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists())
                {
                    chatRef2.child("id").setValue(myUID);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void sendNotification(String hisUID, String fullName, String message) {
        DatabaseReference allTokens = FirebaseDatabase.getInstance().getReference("Tokens");
        Query query =allTokens.orderByKey().equalTo(hisUID);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren())
                {
                    Token token = ds.getValue(Token.class);
                    Data data =new Data(myUID,fullName+":"+message,"New Message",hisUID,R.drawable.baseline_account_circle_black_48);

                    Sender sender = new Sender(data, token.getToken());
                    apiService.sendNotification(sender)
                            .enqueue(new Callback<Response>() {
                                @Override
                                public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                                  //  Toast.makeText(ChatActivity.this, ""+response.message(), Toast.LENGTH_SHORT).show();
                                }

                                @Override
                                public void onFailure(Call<Response> call, Throwable t) {

                                }
                            });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void checkUserStatus()
    {
        FirebaseUser user=mAuth.getCurrentUser();
        if(user!=null)
        {

        }
        else
        {
            startActivity(new Intent(getApplicationContext(),Donor.class));
            finish();

        }
    }

    private void checkOnlineStatus(String  status)
    {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("users");
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren())
                {
                    for(DataSnapshot dataSnapshot2 : dataSnapshot1.getChildren())
                    {
                        if(user.getUid().equals(dataSnapshot2.getKey()))
                        {
                            Map<String,Object> data = (HashMap<String,Object>)dataSnapshot2.getValue();
                            String userType =(String) data.get("userType");
                            //update value of online status of current user
                            if(userType.equals("Donor"))
                            {
                                databaseReference.child("Donor").child(user.getUid()).child("onlineStatus").setValue(status);
                            }
                            else
                            {
                                databaseReference.child("Recipient").child(user.getUid()).child("onlineStatus").setValue(status);
                            }

                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void checkTypingStatus(String  typing)
    {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("users");
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren())
                {
                    for(DataSnapshot dataSnapshot2 : dataSnapshot1.getChildren())
                    {
                        if(user.getUid().equals(dataSnapshot2.getKey()))
                        {
                            Map<String,Object> data = (HashMap<String,Object>)dataSnapshot2.getValue();
                            String userType =(String) data.get("userType");
                            //update value of online status of current user
                            if(userType.equals("Donor"))
                            {
                                databaseReference.child("Donor").child(user.getUid()).child("typingTo").setValue(typing);
                            }
                            else
                            {
                                databaseReference.child("Recipient").child(user.getUid()).child("typingTo").setValue(typing);
                            }

                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    protected void onStart() {
        checkUserStatus();
        // set onlineStatus
        checkOnlineStatus("online");
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //get timestamp
        String timeStamp = String.valueOf(System.currentTimeMillis());

        //set offline with Last Seen timestamp
        checkOnlineStatus(timeStamp);
        checkTypingStatus("noOne");
        userRefForSeen.removeEventListener(seenListener);
    }

    @Override
    protected void onResume() {
        //set Online
        checkOnlineStatus("online");
        checkTypingStatus("noOne");
        super.onResume();
    }
//    private void loadProfile(String url) {
//        Log.d(TAG, "Image cache path: " + url);
//
//        GlideApp.with(this).load(url)
//                .into(imgProfile);
//        imgProfile.setColorFilter(ContextCompat.getColor(this, android.R.color.transparent));
//    }
    private void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ChatActivity.this);
        builder.setTitle(getString(R.string.dialog_permission_title));
        builder.setMessage(getString(R.string.dialog_permission_message));
        builder.setPositiveButton(getString(R.string.go_to_settings), (dialog, which) -> {
            dialog.cancel();
            openSettings();
        });
        builder.setNegativeButton(getString(android.R.string.cancel), (dialog, which) -> dialog.cancel());
        builder.show();

    }

    // navigating user to app settings
    private void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }
}
