package com.example.getblood.Activities;

import android.content.Intent;
import android.os.Bundle;

import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;


import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.getblood.R;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.squareup.picasso.Picasso;

public class ContiueFacebook extends AppCompatActivity {
    private CallbackManager callbackManager;
    private LoginButton fbLoginButton;
    private ImageView profileImageView;
    private FirebaseAuth mFirebaseAuth;
    private AccessTokenTracker accessTokenTracker;
    private FirebaseAuth.AuthStateListener authStateListener;
    private static final String TAG="Facebook Authentication";
    private TextView usernameTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contiue_facebook);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar=getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("Continue to fb login");
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.hide();
        callbackManager = CallbackManager.Factory.create();
        fbLoginButton=findViewById(R.id.fbLoginButton);
        fbLoginButton.setReadPermissions("email","public_profile");
        profileImageView=findViewById(R.id.profileImageView);
        usernameTextView=findViewById(R.id.usernameTextView);
        mFirebaseAuth=FirebaseAuth.getInstance();
        FacebookSdk.sdkInitialize(getApplicationContext());
        LoginManager.getInstance().registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        // App code
                        Log.d(TAG,"onSuccess"+ loginResult);
                        handleFacebookToken(loginResult.getAccessToken());
                    }

                    @Override
                    public void onCancel() {
                        // App code
                        Log.d(TAG,"onCancel");

                    }

                    @Override
                    public void onError(FacebookException exception) {
                        // App code
                        Log.d(TAG,"onError"+ exception);
                    }
                });
        authStateListener=new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user=firebaseAuth.getCurrentUser();
                if(user!=null)
                {
                    updateUI(user);
                }else
                {
                    updateUI(null);
                }
            }
        };
        accessTokenTracker =new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(AccessToken oldAccessToken, AccessToken currentAccessToken) {
                if(currentAccessToken==null)
                {
                    mFirebaseAuth.signOut();
                }
            }
        };

    }
    private void handleFacebookToken(AccessToken token)
    {
        Log.d(TAG,"handleFacebookToken"+ token);

        AuthCredential credential= FacebookAuthProvider.getCredential(token.getToken());
        mFirebaseAuth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Log.d(TAG,"sign in with credential successful");
                    FirebaseUser user=mFirebaseAuth.getCurrentUser();
                    updateUI(user);
                }else{
                    Log.d(TAG,"sign in with credential : failure",task.getException());
                    Toast.makeText(ContiueFacebook.this, "Authentication Failed", Toast.LENGTH_SHORT).show();
                    updateUI(null);
                }
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode,int resultCode, Intent data){
        callbackManager.onActivityResult(requestCode,resultCode,data);
        super.onActivityResult(requestCode,resultCode,data);
    }

    private void updateUI(FirebaseUser user)
    {
        if(user!=null)
        {
            usernameTextView.setText(user.getDisplayName());
            if(user.getPhotoUrl()!=null)
            {
                String photoUrl=user.getPhotoUrl().toString();
                photoUrl=photoUrl + "?type=large";
                Picasso.get().load(photoUrl).into(profileImageView);
                startActivity(new Intent(getApplicationContext(),DashBoard.class));
            }
            if(user.getPhoneNumber()!=null)
            {
                String phoneNo=user.getPhoneNumber();
                Toast.makeText(this, phoneNo, Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            usernameTextView.setText("");
            profileImageView.setImageResource(R.drawable.com_facebook_profile_picture_blank_portrait);
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        mFirebaseAuth.addAuthStateListener(authStateListener);
    }

    @Override
    protected void onStop() {
        super.onStop();

        if(authStateListener!=null)
        {
            mFirebaseAuth.removeAuthStateListener(authStateListener);

        }
    }
    }

