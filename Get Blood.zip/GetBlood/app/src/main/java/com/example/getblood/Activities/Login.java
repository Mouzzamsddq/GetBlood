package com.example.getblood.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.getblood.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;

import java.net.PasswordAuthentication;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public class Login extends AppCompatActivity {
    public static final String TAG = "TAG";
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=.*[0-9])" +         //at least 1 digit
                    "(?=.*[a-z])" +         //at least 1 lower case letter
                    "(?=.*[A-Z])" +         //at least 1 upper case letter
                    //"(?=.*[a-zA-Z])" +      //any letter
                    "(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                    ".{6,}" +               //at least 4 characters
                    "$");
    TextInputEditText textInputPhone, otpEditText;
    Button signUp;
    String phoneNum;
    private String userOtp;
    ProgressBar progressBar;
    FirebaseAuth mAuth;
    Button loginViaPhoneButton;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks verificationStateChangedCallbacks;
    String phoneInput;
    String verificationId;
    TextView timerTextView;
    CountDownTimer countDownTimer;
    PhoneAuthProvider.ForceResendingToken token;
    ProgressDialog pd;
    Button sendOtpButton;
    CountryCodePicker codePicker;
    private boolean check = true;

    public void signUpButton(View v) {
        Intent createAccount = new Intent(getApplicationContext(), Createaccount.class);
        startActivity(createAccount);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        textInputPhone = findViewById(R.id.phoneLoginEditText);
        signUp = (Button) findViewById(R.id.signUpButton);
        otpEditText = findViewById(R.id.otpEditText);
        sendOtpButton = findViewById(R.id.sendOtpButton);
        codePicker = findViewById(R.id.ccp);
        timerTextView = findViewById(R.id.timer2);
        loginViaPhoneButton = findViewById(R.id.loginViaPhoneButton);
        progressBar = findViewById(R.id.progressBar);
        pd = new ProgressDialog(this);
        pd.setMessage("Sending...");
        pd.setCancelable(true);
        mAuth = FirebaseAuth.getInstance();
        pd.setCanceledOnTouchOutside(false);
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent createAccount = new Intent(getApplicationContext(), Createaccount.class);
                startActivity(createAccount);
            }
        });
        sendOtpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validatePhone()) {
                    if (check) {
                        phoneNum = "+" + codePicker.getSelectedCountryCode() + phoneInput;
                        Log.d(TAG, "On click :phone No-->" + phoneNum);
                        requestOTP(phoneNum);
                    } else {
                        resendVerificationCode(phoneNum, token);
                    }


                }
            }
        });
        loginViaPhoneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressBar.setVisibility(View.VISIBLE);
                userOtp = otpEditText.getText().toString().trim();

                if (!userOtp.isEmpty() && userOtp.length() == 6) {
                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, userOtp);
                    verifyAuth(credential);
                } else {
                    progressBar.setVisibility(View.INVISIBLE);
                    Toast.makeText(Login.this, "Please enter a valid OTP!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void requestOTP(String phoneNum) {
        pd.show();
        PhoneAuthProvider.getInstance().verifyPhoneNumber(phoneNum, 60L, TimeUnit.SECONDS, this, verificationStateChangedCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                super.onCodeSent(s, forceResendingToken);
                Toast.makeText(Login.this, "OTP has been sent to your mobile number!", Toast.LENGTH_SHORT).show();
                verificationId = s;
                token = forceResendingToken;
                pd.dismiss();
                sendOtpButton.setText("Sent");
                sendOtpButton.setEnabled(false);
                timerTextView.setVisibility(View.VISIBLE);
                countDownTimer = new CountDownTimer(60000, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        updateTimer((int) millisUntilFinished / 1000);
                    }

                    @Override
                    public void onFinish() {
                        Toast.makeText(Login.this, "Time Out!", Toast.LENGTH_SHORT).show();
                        timerTextView.setVisibility(View.INVISIBLE);
                        timerTextView.setTextColor(getResources().getColor(R.color.colorBlack));
                    }
                }.start();


            }

            @Override
            public void onCodeAutoRetrievalTimeOut(@NonNull String s) {
                super.onCodeAutoRetrievalTimeOut(s);
                sendOtpButton.setEnabled(true);
                sendOtpButton.setText("Resend OTP");
                check = false;

            }

            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {
                Toast.makeText(Login.this, "OTP could not be send to this number!" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void verifyAuth(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    progressBar.setVisibility(View.INVISIBLE);
                    Toast.makeText(Login.this, "Successfully logged in", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), DashBoard.class));

                } else {
                    progressBar.setVisibility(View.INVISIBLE);
                    Toast.makeText(Login.this, "Invalid OTP", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void resendVerificationCode(String phoneNumber,
                                        PhoneAuthProvider.ForceResendingToken token) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                verificationStateChangedCallbacks,         // OnVerificationStateChangedCallbacks
                token);


    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exitByBackKey();

            //moveTaskToBack(false);

            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    protected void exitByBackKey() {
        startActivity(new Intent(Login.this, LogInOptions.class));
        finish();


    }


    public boolean validatePhone() {
        phoneInput = textInputPhone.getText().toString().trim();
        if (phoneInput.isEmpty()) {
            textInputPhone.setError("Field can't be empty");
            return false;
        } else if (!Patterns.PHONE.matcher(phoneInput).matches()) {
            textInputPhone.setError("Please enter a valid phone no!");
            return false;
        } else if (phoneInput.length() < 10) {
            textInputPhone.setError("Please enter a valid phone no!");
            return false;
        } else {
            textInputPhone.setError(null);
            return true;
        }

    }

    public void updateTimer(int secondLeft) {
        check = false;
        int minutes = secondLeft / 60;
        int seconds = secondLeft - minutes * 60;
        String secondString = Integer.toString(seconds);
        if (seconds <= 9) {
            secondString = "0" + secondString;
        }
        if (secondLeft < 10) {
            timerTextView.setTextColor(getResources().getColor(R.color.colorBlood));
            timerTextView.setText(Integer.toString(minutes) + ":" + secondString);
        }
        timerTextView.setText(Integer.toString(minutes) + ":" + secondString);


    }
}








