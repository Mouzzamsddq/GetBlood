package com.example.getblood.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.getblood.Activities.ChatActivity;
import com.example.getblood.DataModel.ModelUser;
import com.example.getblood.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class AdapterUser extends  RecyclerView.Adapter<AdapterUser.MyHolder> {
     Context context;
     List<ModelUser> userList;

    public AdapterUser(Context context, List<ModelUser> userList) {
        this.context = context;
        this.userList = userList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.request_list_item,parent,false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
         // get Data
        String hisUID=userList.get(position).getUID();
        String blood=userList.get(position).getBlood();
        String name="Requested by: "+userList.get(position).getFullName();
        String contact=userList.get(position).getContact();
        String location=userList.get(position).getCity()+", "+userList.get(position).getState();
        String userType=userList.get(position).getUserType();
        String profileImage=userList.get(position).getProfileImage();

        //set data
        holder.nameTextView.setText(name);
        holder.userTypeTextView.setText(userType);
        holder.bloodTextView.setText(blood);
        holder.contactTextView.setText(contact);
        holder.locationTextView.setText(location);
        try
        {
            Picasso.get().load(profileImage)
                    .placeholder(R.drawable.baseline_account_circle_black_48).into(holder.profileImageView);
        }
        catch (Exception e)
        {

        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ChatActivity.class);
                intent.putExtra("hisUID",hisUID);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    //View holder class
    class MyHolder extends RecyclerView.ViewHolder{
        ImageView profileImageView;
        TextView bloodTextView,nameTextView,contactTextView,locationTextView,userTypeTextView;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            //init the views
            profileImageView=itemView.findViewById(R.id.profileImageView);
            bloodTextView=itemView.findViewById(R.id.bloodTextView);
            nameTextView=itemView.findViewById(R.id.nameTextView);
            locationTextView=itemView.findViewById(R.id.locationTextView);
            contactTextView=itemView.findViewById(R.id.contactTextView);
            userTypeTextView=itemView.findViewById(R.id.userTypeTextView);
        }
    }

}
