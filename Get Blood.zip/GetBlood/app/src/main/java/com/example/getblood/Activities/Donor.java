package com.example.getblood.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.getblood.R;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

public class Donor extends AppCompatActivity {
    private boolean found= false;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    public static final String EXTRA_FOUND="found";
    public void donor(View view) {
        Toast.makeText(this, "Let's Help the needy!", Toast.LENGTH_SHORT).show();
        Intent loginPage = new Intent(getApplicationContext(),LogInOptions.class);
        startActivity(loginPage);
    }

    public void recipient(View view) {
        Toast.makeText(this, "Find your saviour!", Toast.LENGTH_SHORT).show();
//        Intent loginPage = new Intent(getApplicationContext(), LogInOptions.class);
        openLogInOptionsActivity();
//        startActivity(loginPage);
    }

    private void openLogInOptionsActivity() {
        found=true;
        Intent intent=new Intent(getApplicationContext(),LogInOptions.class);
        intent.putExtra(EXTRA_FOUND,found);
        startActivity(intent);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth=FirebaseAuth.getInstance();
        currentUser=mAuth.getCurrentUser();
        setContentView(R.layout.activity_donor);
        if(currentUser!=null)
        {
            startActivity(new Intent(getApplicationContext(),HomeActivity.class));
            finish();
        }


    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exitByBackKey();

            //moveTaskToBack(false);

            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    protected void exitByBackKey() {

        AlertDialog alertbox = new AlertDialog.Builder(this)
                .setMessage("Do you want to exit application?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                    // do something when the button is clicked
                    public void onClick(DialogInterface arg0, int arg1) {

                        finish();
                        //close();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {

                    // do something when the button is clicked
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                }).show();
    }

}