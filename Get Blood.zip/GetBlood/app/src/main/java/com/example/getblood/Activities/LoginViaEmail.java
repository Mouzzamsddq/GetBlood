package com.example.getblood.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.getblood.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.regex.Pattern;

public class LoginViaEmail extends AppCompatActivity {
    private Button loginViaEmailButton;
    FirebaseAuth mAuth;
    ProgressDialog pd;
    public static final String EXTRA_FOUND="boolean";
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=.*[0-9])" +         //at least 1 digit
                    "(?=.*[a-z])" +         //at least 1 lower case letter
                    "(?=.*[A-Z])" +         //at least 1 upper case letter
                    //"(?=.*[a-zA-Z])" +      //any letter
                    "(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                    ".{6,}" +               //at least 4 characters
                    "$");

    TextInputEditText textInputEmail;
    TextInputEditText textInputPassword;
    private boolean found;
    public void signUpButton(View v)
    {
        Intent createAccount=new Intent(getApplicationContext(),Createaccount.class);
        createAccount.putExtra(EXTRA_FOUND,found);
        startActivity(createAccount);

    }



    public void forgottenPassword(View view)
    {
        Intent mainPage=new Intent(getApplicationContext(), ForgotPassword.class);
        startActivity(mainPage);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_via_email);
        textInputEmail=findViewById(R.id.emailEditText);
        textInputPassword=findViewById(R.id.passwordEditText);
        loginViaEmailButton=findViewById(R.id.loginViaEmailButton);
        found=getIntent().getBooleanExtra(LogInOptions.EXTRA_FOUND,false);
        pd = new ProgressDialog(this);
        pd.setMessage("Loading...");
        pd.setCancelable(true);
        pd.setCanceledOnTouchOutside(false);
        mAuth = FirebaseAuth.getInstance();
        loginViaEmailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email=textInputEmail.getText().toString();
                final String password=textInputPassword.getText().toString();
                try {
                    if(validateEmail() && validatePassword()) {
                        pd.show();
                        mAuth.signInWithEmailAndPassword(email, password)
                                .addOnCompleteListener(LoginViaEmail.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {

                                        if (!task.isSuccessful()) {
                                            if(task.getException() instanceof FirebaseAuthInvalidCredentialsException)
                                            {
                                                Toast.makeText(LoginViaEmail.this, "Invalid Password!", Toast.LENGTH_SHORT).show();

                                            } else if(task.getException() instanceof FirebaseAuthInvalidUserException) {

                                                Toast.makeText(LoginViaEmail.this, "Email not in use", Toast.LENGTH_SHORT).show();
                                            }

                                        } else {
                                            Toast.makeText(LoginViaEmail.this, "Successfully Logged in", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                                            startActivity(intent);
                                            finish();
                                        }
                                        pd.dismiss();
                                    }
                                });
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Please fill all the field.", Toast.LENGTH_LONG).show();
                    }

                } catch (Exception e)
                {
                    e.printStackTrace();
                }
            }

        });

    }
    public boolean validateEmail()
    {
        String emailInput=textInputEmail.getText().toString().trim();
        if(emailInput.isEmpty()) {
            textInputEmail.setError("Field can't be empty");
            return false;
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches())
        {
            textInputEmail.setError("Please enter a valid email address!");
            return false;
        }
        else
        {
            textInputEmail.setError(null);
            return true;
        }

    }
    public boolean validatePassword()
    {
        String passwordInput=textInputPassword.getText().toString().trim();
        if(passwordInput.isEmpty())
        {
            textInputPassword.setError("Field can't be empty");
            return false;
        }else if(!PASSWORD_PATTERN.matcher(passwordInput).matches())
        {
            textInputPassword.setError("Password is too weak");
            return false;
        }
        else
        {
            textInputPassword.setError(null);
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(),Donor.class));
    }
}
