package com.example.getblood.DataModel;

public class user {
    String name;
    String dob;
    String blood;
    String gender;
    String phone;
    String emailId;
    String profile;
}
