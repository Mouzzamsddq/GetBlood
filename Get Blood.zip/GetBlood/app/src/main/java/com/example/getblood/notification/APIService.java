package com.example.getblood.notification;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface APIService {
    @Headers({
            "Content-Type:application/json",
            "Authorization:key=AAAA6_DN_gQ:APA91bFTdw4HUmribaeBoVE8atU5YTp1tPXTBakPuOkZYN3ZCpar9Ab1wnGo7MybLhEFX3kF6YjuHfBbv0S62CIQpMRwnXmPkacVC03wxkTOjan4Lf0ETLDbrkEJ5IGwhwsd1xMHBUui"
    })

    @POST("fcm/send")
    Call<Response> sendNotification(@Body Sender body);
}
