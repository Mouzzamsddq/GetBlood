package com.example.getblood.Activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.getblood.R;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;

import java.util.HashMap;
import java.util.Map;

public class LogInOptions extends AppCompatActivity {
    private Button signInButton;
    private boolean found;
    Button signInViaPhone;
    Button signInViaMail;
    private FirebaseDatabase mDataBase;
    private DatabaseReference mRef;
    private Button signOut;
    public static final String EXTRA_FOUND="found";

    GoogleSignInClient mGoogleSignInClient;
    private final static int RC_SIGN_IN=1;
    private String TAG="LogInOption";
    FirebaseAuth mAuth;

    public void facebookLogin(View v)
    {
        Intent facebookLogin=new Intent(getApplicationContext(),ContiueFacebook.class);
        startActivity(facebookLogin);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mDataBase=FirebaseDatabase.getInstance();
        mRef=mDataBase.getReference().child("users");
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("Sign in options");
        found=getIntent().getBooleanExtra(Donor.EXTRA_FOUND,false);
        actionBar.setDisplayHomeAsUpEnabled(true);
        signInViaPhone=findViewById(R.id.signInViaPhone);
        signInViaMail=findViewById(R.id.signInViaEmail);
        mAuth=FirebaseAuth.getInstance();
        if(mAuth.getCurrentUser() != null)
        {
            Intent intent = new Intent(getApplicationContext(), DashBoard.class);
            startActivity(intent);
            finish();
        }
//
        signInViaMail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signInOptions=new Intent(getApplicationContext(),LoginViaEmail.class);
                signInOptions.putExtra(EXTRA_FOUND,found);
                startActivity(signInOptions);
            }
        });
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.hide();
         signInButton=findViewById(R.id.signInButton);
        mAuth=FirebaseAuth.getInstance();
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
         signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 signIn();
            }
        });

    }
    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Log.w(TAG, "Google sign in failed", e);
                // ...
            }
        }
    }
    private void firebaseAuthWithGoogle(GoogleSignInAccount user) {
        Log.d(TAG, "firebaseAuthWithGoogle:" + user.getId());

        AuthCredential credential = GoogleAuthProvider.getCredential(user.getIdToken(), null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Toast.makeText(LogInOptions.this, "Logged in", Toast.LENGTH_SHORT).show();
                            FirebaseUser user = mAuth.getCurrentUser();
                            String FullName=user.getDisplayName();
                            String contactNo=user.getPhoneNumber();
                            String emailId=user.getEmail();
                            String userId=user.getUid();
                            String profileImage=user.getPhotoUrl().toString();
                            Map<String, String> userData = new HashMap<>();
                            userData.put("FullName", FullName);
                            userData.put("DateOfBirth", "");
                            userData.put("Blood", "");
                            userData.put("Gender", "");
                            userData.put("Contact", "");
                            userData.put("emailId", emailId);
                            userData.put("UID", userId);
                            userData.put("profileImage", profileImage);
                            Task task3;
                            if(found)
                            {
                                task3=mRef.child("Recipient").child(user.getUid()).setValue(userData);
                            }
                            else
                            {
                                task3=mRef.child("Donor").child(user.getUid()).setValue(userData);
                            }
                            task3.addOnSuccessListener(new OnSuccessListener() {
                                @Override
                                public void onSuccess(Object o) {
                                    Toast.makeText(LogInOptions.this, "Successfully Registered", Toast.LENGTH_SHORT).show();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(LogInOptions.this, "Failed to register "+e, Toast.LENGTH_SHORT).show();
                                }
                            });
                            updateUI(user);

                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(LogInOptions.this, "You are not able to login in to google", Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }

                        // ...
                    }
                });
    }

    private void updateUI(FirebaseUser user) {
//        GoogleSignInAccount user = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        if (user != null) {
            String personName = user.getDisplayName();
            String phoneNumber = user.getPhoneNumber();
            String UID = user.getUid();
            String personEmail = user.getEmail();
            String profilePic = user.getPhotoUrl().toString();
            Toast.makeText(this, personName+ "/"+phoneNumber+"/"+UID+"/"+personEmail+"/"+profilePic, Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getApplicationContext(),DashBoard.class));
        }else
        {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
        }


        }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(),Donor.class));
    }
}



