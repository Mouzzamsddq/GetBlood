package com.example.getblood.Fragment;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;

//import com.example.getblood.Activities.ImagePickerActivity;
import com.example.getblood.Activities.ImagePickerActivity;
import com.example.getblood.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class profileFragment extends Fragment {
    private FirebaseDatabase mDatabase;
    private FirebaseAuth mAuth;
    private FirebaseUser user;
    Uri pickedImgUri;
    String storagePath = "users/users_profile_image/";
    boolean found = false;
    private FirebaseStorage storage;
    private StorageReference mStorageRef;
    private static final String TAG = "TAG";
    public static final int REQUEST_IMAGE = 100;
    private View view;
    private ImageView profileImageView, profileImagePlusView;
    private ProgressDialog pd;
    private DatabaseReference mRef;
    private Button updateProfileButton;
    private EditText nameEditText, DobEditText, emailEditText, stateEditText, cityEditText, pinCodeEditText, bloodEdiText, phoneEditText, userTypeEdiText;

    public profileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_profile, container, false);
        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();
        setHasOptionsMenu(true);
        pd = new ProgressDialog(getContext());
        pd.setMessage("Updating Profile...");
        pd.setCanceledOnTouchOutside(false);
        pd.setCancelable(false);
        mDatabase = FirebaseDatabase.getInstance();
        mRef = mDatabase.getReference().child("users");
        storage = FirebaseStorage.getInstance();
        mStorageRef = storage.getReferenceFromUrl("gs://get-blood-f8318.appspot.com");
        nameEditText = view.findViewById(R.id.usernameEditText);
        DobEditText = view.findViewById(R.id.dobEditText);
        emailEditText = view.findViewById(R.id.emailEditText);
        stateEditText = view.findViewById(R.id.stateEditText);
        cityEditText = view.findViewById(R.id.cityEditText);
        pinCodeEditText = view.findViewById(R.id.pinCodeEditText);
        bloodEdiText = view.findViewById(R.id.bloodEditText);
        phoneEditText = view.findViewById(R.id.contactEditText);
        userTypeEdiText = view.findViewById(R.id.userTypeEdiText);
        profileImageView = view.findViewById(R.id.profileImageView);
        updateProfileButton = view.findViewById(R.id.updateProfileButton);
        profileImageView = view.findViewById(R.id.profileImageView);
        profileImagePlusView = view.findViewById(R.id.imagePlusProfile);
        mRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot donorRecipientSnapshot : dataSnapshot.getChildren()) {
                    for (DataSnapshot usersSnapshot : donorRecipientSnapshot.getChildren()) {
                        if (user.getUid().equals(usersSnapshot.getKey())) {
                            Map<String, Object> data = (HashMap<String, Object>) usersSnapshot.getValue();
                            String name = (String) data.get("FullName");
                            String dob = (String) data.get("DateOfBirth");
                            String blood = (String) data.get("Blood");
                            String Contact = (String) data.get("Contact");
                            String state = (String) data.get("state");
                            String city = (String) data.get("city");
                            String pinCode = (String) data.get("pin");
                            String email = (String) data.get("emailId");
                            String userType = (String) data.get("userType");
                            nameEditText.setText(name);
                            DobEditText.setText(dob);
                            emailEditText.setText(email);
                            stateEditText.setText(state);
                            cityEditText.setText(city);
                            bloodEdiText.setText(blood);
                            userTypeEdiText.setText(userType);
                            pinCodeEditText.setText(pinCode);
                            phoneEditText.setText(Contact);
                            String profileUrl = (String) data.get("profileImage");
                            if (!profileUrl.isEmpty()) {
                                Picasso.get().load(profileUrl).placeholder(R.drawable.baseline_account_circle_black_48).into(profileImageView);
                            }
                        }
                    }
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        // Clearing older images from cache directory
        // don't call this line if you want to choose multiple images in the same activity
        // call this once the bitmap(s) usage is over
        ImagePickerActivity.clearCache(getContext());
        updateProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pd.show();

                String name = nameEditText.getText().toString().trim();
                String email = emailEditText.getText().toString().trim();
                String phone = phoneEditText.getText().toString().trim();

                mRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot donorRecipient : dataSnapshot.getChildren()) {
                            for (DataSnapshot usersSnapshot : donorRecipient.getChildren()) {
                                if (user.getUid().equals(usersSnapshot.getKey())) {
                                    Map<String, Object> data = (HashMap<String, Object>) usersSnapshot.getValue();
                                    String userType = (String) data.get("userType");
                                    if (userType.equals("Donor")) {
                                        mRef.child("Donor").child(user.getUid()).child("FullName").setValue(name);
                                        mRef.child("Donor").child(user.getUid()).child("emailId").setValue(email);
                                        mRef.child("Donor").child(user.getUid()).child("Contact").setValue(phone);
                                        found = false;
                                    } else {

                                        mRef.child("Recipient").child(user.getUid()).child("FullName").setValue(name);
                                        mRef.child("Recipient").child(user.getUid()).child("emailId").setValue(email);
                                        mRef.child("Recipient").child(user.getUid()).child("Contact").setValue(phone);
                                        found = true;
                                    }
                                    if(pickedImgUri != null && !pickedImgUri.equals(Uri.EMPTY)) {
                                        uploadImageToFirebase(pickedImgUri);
                                    }
                                    else
                                    {
                                        pd.dismiss();
                                    }


                                }
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });
        profileImagePlusView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dexter.withActivity(getActivity())
                        .withPermissions(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        .withListener(new MultiplePermissionsListener() {
                            @Override
                            public void onPermissionsChecked(MultiplePermissionsReport report) {
                                if (report.areAllPermissionsGranted()) {
                                    showImagePickerOptions();
                                }

                                if (report.isAnyPermissionPermanentlyDenied()) {
                                    showSettingsDialog();
                                }
                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                                token.continuePermissionRequest();
                            }
                        }).check();
            }

        });
        return view;
    }

    private void loadProfile(String url) {
        Log.d(TAG, "Image cache path: " + url);

        Picasso.get().load(url).placeholder(R.drawable.baseline_account_circle_black_48)
                .into(profileImageView);
        profileImageView.setColorFilter(ContextCompat.getColor(getContext(), android.R.color.transparent));
    }

//    private void loadProfileDefault() {
//        GlideApp.with(this).load(R.drawable.baseline_account_circle_black_48)
//                .into(profileImageView);
//        profileImageView.setColorFilter(ContextCompat.getColor(getContext(), R.color.profile_default_tint));
//    }


    private void showImagePickerOptions() {
        ImagePickerActivity.showImagePickerOptions(getContext(), new ImagePickerActivity.PickerOptionListener() {
            @Override
            public void onTakeCameraSelected() {
                launchCameraIntent();
            }

            @Override
            public void onChooseGallerySelected() {
                launchGalleryIntent();
            }
        });
    }

    private void launchCameraIntent() {
        Intent intent = new Intent(getContext(), ImagePickerActivity.class);
        intent.putExtra(ImagePickerActivity.INTENT_IMAGE_PICKER_OPTION, ImagePickerActivity.REQUEST_IMAGE_CAPTURE);

        // setting aspect ratio
        intent.putExtra(ImagePickerActivity.INTENT_LOCK_ASPECT_RATIO, true);
        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_X, 1); // 16x9, 1x1, 3:4, 3:2
        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_Y, 1);

        // setting maximum bitmap width and height
        intent.putExtra(ImagePickerActivity.INTENT_SET_BITMAP_MAX_WIDTH_HEIGHT, true);
        intent.putExtra(ImagePickerActivity.INTENT_BITMAP_MAX_WIDTH, 1000);
        intent.putExtra(ImagePickerActivity.INTENT_BITMAP_MAX_HEIGHT, 1000);

        startActivityForResult(intent, REQUEST_IMAGE);
    }

    private void launchGalleryIntent() {
        Intent intent = new Intent(getContext(), ImagePickerActivity.class);
        intent.putExtra(ImagePickerActivity.INTENT_IMAGE_PICKER_OPTION, ImagePickerActivity.REQUEST_GALLERY_IMAGE);

        // setting aspect ratio
        intent.putExtra(ImagePickerActivity.INTENT_LOCK_ASPECT_RATIO, true);
        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_X, 1); // 16x9, 1x1, 3:4, 3:2
        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_Y, 1);
        startActivityForResult(intent, REQUEST_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE) {
            if (resultCode == Activity.RESULT_OK) {
                Uri uri = data.getParcelableExtra("path");
                pickedImgUri = uri;
                try {
                    // You can update this bitmap to your server
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), uri);

                    // loading profile image from local cache
                    loadProfile(uri.toString());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void uploadImageToFirebase(Uri imgUri) {
        if (found) {
            storagePath = storagePath + "Recipient_profile/profile_" + user.getUid() + ".png";
            mStorageRef = mStorageRef.child(storagePath);
        } else {
            storagePath = storagePath + "Donor_profile/profile_" + user.getUid() + ".png";
            mStorageRef = mStorageRef.child(storagePath);
        }
            mStorageRef.putFile(imgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    pd.dismiss();
                    mStorageRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            Picasso.get().load(uri).into(profileImageView);
                            Map<String, Object> results = new HashMap<>();
                            results.put("profileImage", uri.toString());
                            Task task2;
                            if (found) {
                                task2 = mRef.child("Recipient").child(user.getUid()).updateChildren(results);
                            } else {
                                task2 = mRef.child("Donor").child(user.getUid()).updateChildren(results);
                            }
                            task2.addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    pd.dismiss();
                                    Toast.makeText(getContext(), "Profile Updated", Toast.LENGTH_SHORT).show();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(getContext(), "Error in uploading image", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    });
                }

            });
        }


    /**
     * Showing Alert Dialog with Settings option
     * Navigates user to app settings
     * NOTE: Keep proper title and message depending on your app
     */
    private void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(getString(R.string.dialog_permission_title));
        builder.setMessage(getString(R.string.dialog_permission_message));
        builder.setPositiveButton(getString(R.string.go_to_settings), (dialog, which) -> {
            dialog.cancel();
            openSettings();
        });
        builder.setNegativeButton(getString(android.R.string.cancel), (dialog, which) -> dialog.cancel());
        builder.show();

    }

    // navigating user to app settings
    private void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getActivity().toString(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }


}
